from django.apps import AppConfig


class EmailProcessorAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'email_processor_app'
